from re import template
from django.urls import path
from django.contrib.auth import views as auth_views             
from . import views

urlpatterns = [
    path('login', views.index, name='index'),
    path('register',views.register, name='register'),
    path('',views.Home, name='Home'),
    path('about/<str:e>',views.about, name='about'),
    path('training',views.training, name='training'),
    path('aboutus',views.aboutus, name='aboutus'),
    path('workouts',views.workout_s, name='workouts'),
    path('workout/<str:plan>/<str:num>',views.workout, name='workout'),
    path('createPlan/<str:plan>',views.createPlan,name='createPlan'),
    path('signout',views.signout ,name='signout'),
    path('finish',views.finish,name='finish'),
    path('reset_password',auth_views.PasswordResetView.as_view(template_name='reset_password.html'),name='reset_password'),
    path('reset_password_sent',auth_views.PasswordResetDoneView.as_view(template_name='reset_password_sent.html'),name='password_reset_done'),
    path('reset/<uidb64>/<token>',auth_views.PasswordResetConfirmView.as_view(),name='password_reset_confirm'),
    path('reset_password_complete',auth_views.PasswordResetCompleteView.as_view(template_name='reset_password_done.html'),name='password_reset_complete')
    
]

