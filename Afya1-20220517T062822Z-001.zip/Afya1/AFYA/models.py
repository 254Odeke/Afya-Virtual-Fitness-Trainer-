
from tkinter import CASCADE
from django.db import models
from django.contrib.auth.models import User
from datetime import datetime,date

# Create your models here.

class Status(models.Model):
    WorkoutType =(
        ('SixPack', 'SixPack'),
        ('HardABS', 'HardABS'),
        ('Belly Fat', 'Belly Fat')
    )
    name = models.CharField(max_length=60)
    user_id = models.OneToOneField(User, on_delete=models.CASCADE) 
    Workout = models.CharField(blank=True, choices=WorkoutType,max_length=20)
    StartDate = models.DateTimeField(auto_now_add=True)
    Day1= models.FloatField(default=0)
    Day2= models.FloatField(default=0)
    DAY3= models.FloatField(default=0)
    Day4= models.FloatField(default=0)
    Day5= models.FloatField(default=0)
    Day6= models.FloatField(default=0)
    Day7= models.FloatField(default=0)
    Day8= models.FloatField(default=0)
    Day9= models.FloatField(default=0)
    Day10= models.FloatField(default=0)
    Day11= models.FloatField(default=0)
    Day12= models.FloatField(default=0)
    DAY13= models.FloatField(default=0)
    Day14= models.FloatField(default=0)
    Day15= models.FloatField(default=0)
    Day16= models.FloatField(default=0)
    Day17= models.FloatField(default=0)
    Day18= models.FloatField(default=0)
    Day19= models.FloatField(default=0)
    Day20= models.FloatField(default=0)
    Day21= models.FloatField(default=0)
    Day22= models.FloatField(default=0)
    DAY23= models.FloatField(default=0)
    Day24= models.FloatField(default=0)
    Day25= models.FloatField(default=0)
    Day26= models.FloatField(default=0)
    Day27= models.FloatField(default=0)
    Day28= models.FloatField(default=0)
    Day29= models.FloatField(default=0)
    Day30= models.FloatField(default=0)
    progress= models.IntegerField(default=0)
    
    def __str__(self) :
        return self.name
    
    @property
    def no_of_days(self):
        today = date.today()
        start = self.StartDate.date()
        days_s = today - start
        if str(days_s) == "0:00:00"  :
            days = 0
        else :
            days = str(days_s).split(" ",1)[0]
        
        return int(days)+1