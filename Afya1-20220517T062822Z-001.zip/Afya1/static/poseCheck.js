//single video analysis and storing data
var exe = document.getElementsByTagName('h1')[0].textContent
// var exe = document.getElementById("hi");
let url0 = "/../../static/workout videos/_.mp4"
let url;
let total=0,good=0;
let live;
let poseNet;
let poses = [];
let v=[],v1=[];
let test=false;
let video;
var videoIsPlaying; 

function setup() {
  url = url0.replace('_',str(exe));
  videoIsPlaying = false; 
  createCanvas(650, 360,350,0);
  video = createVideo(url, vidLoad);
  live=createCapture(VIDEO);
  live.hide();
  vidLoad();
  video.autoplay();
  video.size(width, height);

  // Create a new poseNet method with a single detection
  poseNet = ml5.poseNet(video, modelReady);
  poseNet.on('pose', loaded);
  // Hide the video element, and just show the canvas
  video.hide();
}
loaded=function(results) {
  poses = results;
  
  if(poses.length>0){
    
    // console.log(poses);
    if(!test){
          for(let i=0;i<poses.length;i++){
            v.push(poses[i].pose.keypoints);
          }
    }
    else{
      let testvector=[];
      for(let i=0;i<poses[0].pose.keypoints.length;i++){
          testvector.push(poses[0].pose.keypoints[i].position.x);
          testvector.push(poses[0].pose.keypoints[i].position.y);
      }
      let t1=0,t2=0;
      for(let i=0;i<testvector.length;i++){
        t1=t1+Math.pow(testvector[i],2);
      }
      t1=Math.sqrt(t1);
      for(let i=0;i<testvector.length;i++){
        
        testvector[i]=testvector[i]/t1;
      }
      let d,min=weightedDistanceMatching(v1[0],testvector);
      for(let r=1;r<v1.length;r++){
        
        d=weightedDistanceMatching(v1[r],testvector);
        if(d<=min){
          min=d;
        }
        
      }
      let b=0;
      let boo="Wrong";
      if(min<=0.75 ){
          b=1;
          boo="Correct";
      }
      total++;
      good=good+b;
      let g=good*100/total;
      document.getElementById("results").innerHTML =boo ;
      document.getElementById("results1").innerHTML =g ;
      console.log("percentage : "+good*100/total);
      console.log("Distence : "+min);
    }

  }
}



function modelReady() {
  select('#status').html('Model Loaded');
    video.pause();
    videoIsPlaying = false;
    video.loop();
    videoIsPlaying = true;
}



function draw() {
  image(live, 0, 0, width, height);

  // We can call both functions to draw all keypoints and the skeletons
  //drawKeypoints();
  //drawSkeleton();
}

// A function to draw ellipses over the detected keypoints
function drawKeypoints()  {
  // Loop through all the poses detected
  for (let i = 0; i < poses.length; i++) {
    // For each pose detected, loop through all the keypoints
    let pose = poses[i].pose;
    
    for (let j = 0; j < pose.keypoints.length; j++) {
      // A keypoint is an object describing a body part (like rightArm or leftShoulder)
      let keypoint = pose.keypoints[j];
      // Only draw an ellipse is the pose probability is bigger than 0.2
      if (keypoint.score > 0.2) {
      	noStroke();
        fill(255, 0, 0);
        ellipse(keypoint.position.x, keypoint.position.y, 10, 10);
      }
    }
  }
}

// A function to draw the skeletons
function drawSkeleton() {
  // Loop through all the skeletons detected
  for (let i = 0; i < poses.length; i++) {
    let skeleton = poses[i].skeleton;
    // For every skeleton, loop through all body connections
    for (let j = 0; j < skeleton.length; j++) {
      let partA = skeleton[j][0];
      let partB = skeleton[j][1];
      stroke(255, 0, 0);
      line(partA.position.x, partA.position.y, partB.position.x, partB.position.y);
    }
  }
}


// This function is called when the video loads
function vidLoad() {
  video.stop();
  video.loop();
  videoIsPlaying = true;
}

function load(){
  console.log(videoIsPlaying);

    let t=video.duration();
    console.log(url);
    console.log(t);
    console.log(v);
    video.pause();
    videoIsPlaying = false;
    // poseNet.singlePose(video);
    poseNet.removeListener('pose', loaded);

}
function analyse(){
      t=video.duration();
    setTimeout(stop_pose, t*1000);
    video.loop();
    videoIsPlaying = true;
    poseNet.on('pose', loaded);
    v=[];
}
function stop_pose(){
  video.pause();
  videoIsPlaying = false;
  // poseNet.singlePose(video);
  poseNet.removeListener('pose', loaded);
  console.log(v);
  keys();

  normalize();
  confidence();
  console.log(v1);
  test=true;
  poseNet = ml5.poseNet(live, modelReady);
  poseNet.on('pose', loaded);
}
function confidence(){
  for(let i=0;i<v.length;i++){
        let t=0;
        for(let j=0;j<v[i].length;j++){
          let kp=v[i][j].score;
          v1[i].push(kp);
          t=t+kp;
        }
        v1[i].push(t);
  }
}

function normalize(){
  for(let j=0;j<v1.length;j++){
        let t1=0;
        for(let i=0;i<v1[j].length;i++){
          t1=t1+Math.pow(v1[j][i],2);
        }
        t1=Math.sqrt(t1);
        for(let i=0;i<v1[j].length;i++){
          
          v1[j][i]=v1[j][i]/t1;
        }
  }

}

function keys(){
  for(let j=0;j<v.length;j++){
    let e=[];
    v1.push(e);
    for(let i=0;i<v[j].length;i++){
      v1[j].push(v[j][i].position.x);
      v1[j].push(v[j][i].position.y);
    }
  }
}


//weighted method
function weightedDistanceMatching(poseVector1, poseVector2) {
  let vector1PoseXY = poseVector1.slice(0, 34);
  let vector1Confidences = poseVector1.slice(34, 51);
  let vector1ConfidenceSum = poseVector1.slice(51, 52);

  let vector2PoseXY = poseVector2.slice(0, 34);

  // First summation
  let summation1 = 1 / vector1ConfidenceSum;

  // Second summation
  let summation2 = 0;
  for (let i = 0; i < vector1PoseXY.length; i++) {
    let tempConf = Math.floor(i / 2);
    let tempSum = vector1Confidences[tempConf] * Math.abs(vector1PoseXY[i] - vector2PoseXY[i]);
    summation2 = summation2 + tempSum;
  }

  return summation1 * summation2;
}

//cosine method

// function dotProduct(vecA, vecB){
//     let product = 0;
//     for(let i=0;i<vecA.length;i++){
//         product += vecA[i] * vecB[i];
//     }
//     return product;
// }

// function magnitude(vec){
//     let sum = 0;
//     for (let i = 0;i<vec.length;i++){
//         sum += vec[i] * vec[i];
//     }
//     return Math.sqrt(sum);
// }
// function cosineDistanceMatching(poseVector1, poseVector2) {
//         let distance = 2 * (1 - cosineSimilarity(poseVector1, poseVector2));
//         return Math.sqrt(distance);
// }

// function cosineSimilarity(vecA,vecB){
//     return dotProduct(vecA,vecB)/ (magnitude(vecA) * magnitude(vecB));
// }